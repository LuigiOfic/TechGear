// src/screens/Register/index.js

import React from "react";
import { View, Text, Image, TextInput, TouchableOpacity, KeyboardAvoidingView } from "react-native";
import { useNavigation } from "@react-navigation/native";
import styles from "../Register/styles";
import { LinearGradient } from "expo-linear-gradient";
import { Header } from "../../components/Header";

function RegisterScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <LinearGradient
        style={styles.linear}
        colors={["#E9ECEF", "#DEE2E6", "#CED4DA", "#ADB5BD"]}
      >
        <Header></Header>
        <View style={styles.main}>
          <Text style={styles.text}>Informe suas informações</Text>
          <Text style={styles.text}>pessoais</Text>
          <View style={styles.box}>
            <TextInput style={styles.input} placeholder="Nome"></TextInput>
            <TextInput
              style={styles.input}
              placeholder="Número da Matrícula"
              secureTextEntry={true}
            ></TextInput>
            <TextInput style={styles.input} placeholder="Turma"></TextInput>
            <TextInput
              style={styles.input}
              placeholder="Email Educacional"
            ></TextInput>
            <TextInput
              style={styles.input}
              placeholder="Senha"
              secureTextEntry={true}
            ></TextInput>
            <TextInput
              style={styles.input}
              placeholder="Confirmar Senha"
              secureTextEntry={true}
            ></TextInput>
            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate("List")}
            >
              <Text style={styles.txtBtn}>Cadastrar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>
    </View>
  );
}

export default RegisterScreen;
