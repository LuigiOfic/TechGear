import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import styles from "./styles";
import { LinearGradient } from "expo-linear-gradient";
import { Header } from "../../../components/Header";

const Engrenagens = () => {
  const [inputs, setInputs] = useState({
    modulo: "",
    diametro: "",
    anguloConeCabeca: "",
  });
  const [resultados, setResultados] = useState(null);

  const handleChange = (field, value) => {
    setInputs((prevInputs) => ({ ...prevInputs, [field]: value }));
  };

  const calcularEngrenagem = () => {
    const moduloNumber = parseFloat(inputs.modulo);

    if (isNaN(moduloNumber)) {
      return;
    }

    const alturaDenteCalculada = moduloNumber * 2.25;
    const alturaCabecaDenteCalculada = moduloNumber * 2.5;
    const folgaCabecaCalculada = moduloNumber * 0.25;

    setResultados({
      alturaDenteCalculada: alturaDenteCalculada.toFixed(3),
      alturaCabecaDenteCalculada: alturaCabecaDenteCalculada.toFixed(3),
      folgaCabecaCalculada: folgaCabecaCalculada.toFixed(3),
    });
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        style={styles.linear}
        colors={["#E9ECEF", "#DEE2E6", "#CED4DA", "#ADB5BD"]}
      >
        <Header></Header>

        <Text style={styles.titulo}>Engrenagens Cônicas</Text>

        <View style={styles.main}>
          <View style={styles.box}>
            {Object.entries(inputs).map(([field, value]) => (
              <TextInput
                key={field}
                value={value}
                onChangeText={(text) => handleChange(field, text)}
                style={styles.input}
                keyboardType="numeric"
                placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
              />
            ))}
          </View>

          <TouchableOpacity onPress={calcularEngrenagem} style={styles.button}>
            <Text style={styles.txtBtn}>Calcular</Text>
          </TouchableOpacity>

          {resultados && (
            <View style={styles.resultContainer}>
              {Object.entries(resultados).map(([key, value]) => (
                <Text key={key} style={styles.resultText}>{`${key}: ${value}`}</Text>
              ))}
            </View>
          )}
        </View>
      </LinearGradient>
    </View>
  );
};

export default Engrenagens;
