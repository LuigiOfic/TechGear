import { StyleSheet } from "react-native";

const style = StyleSheet.create({
  container: {
    height: "100%",
    width: "100%",
  },
  linear: {
    height: "100%",
    alignItems: "center",
  },
  header: {
    height: "25%",
    width: "100%",
    flexDirection: "column",
    borderColor: "black",
    alignItems: "center",
  },
  menu: {
    marginTop: "1%",
    marginLeft: "90%",
  },
  main: {
    height: "60%",
    width: "80%",
    alignItems: "center",
    justifyContent: "center",
  },
  box: {
    height: "80%",
    width: "40%",
    alignItems: "center",
    backgroundColor: "#ADB5BD",
    borderRadius: 5,
    shadowColor: 'black',
    shadowRadius: 10,
  },
  text: {
    fontSize: 15,
    marginBottom: 10,
  },
  input: {
    backgroundColor: "white",
    padding: 10,
    height: "15%",
    width: "70%",
    borderRadius: 5,
    marginVertical: 10,
  },
  button: {
    height: 40,
    width: 150,
    borderRadius: 5,
    padding: 10,
    backgroundColor: "#212529",
    alignItems: "center",
  },
  txtBtn: {
    color: "white",
  },
});

export default style;
