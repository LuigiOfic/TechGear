// src/screens/Transmissao/index.js

import React from 'react';
import { View, Text, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';

function TransmissaoScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Transmissao</Text>
      <Button
        title="Go to List"
        onPress={() => navigation.navigate('List')}
      />

    </View>
  );
}

export default TransmissaoScreen;
