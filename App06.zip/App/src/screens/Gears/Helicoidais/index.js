// Importações necessárias do React Native
import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet } from "react-native";
import style from "./styles";
import { Header } from "../../../components/Header";
import { LinearGradient } from "expo-linear-gradient";

// Componente principal do aplicativo
function GearCalculator() {
  // Estados para armazenar o módulo e o número de dentes
  const [modulo, setModulo] = useState("");
  const [numDentes, setNumDentes] = useState("");
  const [diametroPrimitivo, setDiametroPrimitivo] = useState("");

  // Função para calcular o diâmetro primitivo
  const calcularDiametroPrimitivo = () => {
    // Converter valores para números
    const m = parseFloat(modulo);
    const Z = parseInt(numDentes);

    // Calcular o diâmetro do círculo primitivo
    const diametro = m * Z;

    // Atualizar o estado do diâmetro primitivo
    setDiametroPrimitivo(diametro.toFixed(2)); // Arredondar para duas casas decimais
  };

  return (
    <View style={style.container}>
      <LinearGradient
        style={style.linear}
        colors={["#E9ECEF", "#DEE2E6", "#CED4DA", "#ADB5BD"]}
      >
        <Header></Header>
        <View style={style.main}>
          <View style={style.box}>
            <TextInput
              style={style.input}
              placeholder="Módulo"
              value={modulo}
              onChangeText={(text) => setModulo(text)}
              keyboardType="numeric"
            />
            <TextInput
              style={style.input}
              placeholder="Numero De Dentes"
              value={numDentes}
              onChangeText={(text) => setNumDentes(text)}
              keyboardType="numeric"
            />
          </View>
          <Button
            title="Calcular Diâmetro Primitivo"
            onPress={calcularDiametroPrimitivo}
          />
          {diametroPrimitivo !== "" && (
            <Text style={style.result}>
              Diâmetro Primitivo: {diametroPrimitivo}
            </Text>
          )}
        </View>
      </LinearGradient>
    </View>
  );
}

export default GearCalculator;
