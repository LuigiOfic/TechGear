import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';

const EngrenagemConicaVariavel = () => {
  const [modulo, setModulo] = useState('');
  const [z1, setZ1] = useState('');
  const [z2, setZ2] = useState('');
  const [resultadoD1, setResultadoD1] = useState(null);
  const [resultadoD2, setResultadoD2] = useState(null);
  const [resultadoCirculoCabeca1, setResultadoCirculoCabeca1] = useState(null);
  const [resultadoCirculoCabeca2, setResultadoCirculoCabeca2] = useState(null);
  const [resultadoAnguloPrimitivo1, setResultadoAnguloPrimitivo1] = useState(null);
  const [resultadoAnguloPrimitivo2, setResultadoAnguloPrimitivo2] = useState(null);

  const calcularEngrenagem = () => {
    // Converter inputs para números
    const moduloNumero = parseFloat(modulo);
    const z1Numero = parseInt(z1);
    const z2Numero = parseInt(z2);

    // Realizar os cálculos conforme as fórmulas fornecidas
    const d1 = (moduloNumero * z1Numero).toFixed(3);
    const d2 = (moduloNumero * z2Numero).toFixed(3);

    // Calcular outros parâmetros conforme necessário
    const da1 = (parseFloat(d1) + 2 * moduloNumero * Math.cos(8)).toFixed(3);
    const da2 = (moduloNumero * z2Numero + 2 * moduloNumero * Math.cos(8)).toFixed(3);
    const dar1 = (moduloNumero * z1Numero + 2 * moduloNumero * Math.cos(8)).toFixed(3);
    const dar2 = (moduloNumero * z2Numero + 2 * moduloNumero * Math.cos(8)).toFixed(3);

    // Atualizar os resultados
    setResultadoD1(d1);
    setResultadoD2(d2);
    setResultadoCirculoCabeca1(da1);
    setResultadoCirculoCabeca2(da2);
    setResultadoAnguloPrimitivo1(dar1);
    setResultadoAnguloPrimitivo2(dar2);
  };

  return (
    <View>
      <Text>Engrenagem Cônica Variável</Text>
      <TextInput
        placeholder="Modulo (m)"
        keyboardType="numeric"
        value={modulo}
        onChangeText={(text) => setModulo(text)}
      />
      <TextInput
        placeholder="Número de dentes (Z1)"
        keyboardType="numeric"
        value={z1}
        onChangeText={(text) => setZ1(text)}
      />
      <TextInput
        placeholder="Número de dentes (Z2)"
        keyboardType="numeric"
        value={z2}
        onChangeText={(text) => setZ2(text)}
      />
      <Button title="Calcular" onPress={calcularEngrenagem} />

      {resultadoD1 && (
        <Text>Diâmetro primitivo da engrenagem 1: {resultadoD1}</Text>
      )}
      {resultadoD2 && (
        <Text>Diâmetro primitivo da engrenagem 2: {resultadoD2}</Text>
      )}
      {resultadoCirculoCabeca1 && (
        <Text>Círculo da cabeça da engrenagem 1: {resultadoCirculoCabeca1}</Text>
      )}
      {resultadoCirculoCabeca2 && (
        <Text>Círculo da cabeça da engrenagem 2: {resultadoCirculoCabeca2}</Text>
      )}
      {resultadoAnguloPrimitivo1 && (
        <Text>Ângulo primitivo da engrenagem 1: {resultadoAnguloPrimitivo1}</Text>
      )}
      {resultadoAnguloPrimitivo2 && (
        <Text>Ângulo primitivo da engrenagem 2: {resultadoAnguloPrimitivo2}</Text>
      )}
    </View>
  );
};

export default EngrenagemConicaVariavel;
