import { StyleSheet, Platform } from "react-native";

const style = StyleSheet.create({
  container: {
    height: "100%",
    width: "100%",
  },
  
});

export default style;
