package com.GearTech.geartech.repository;

import com.GearTech.geartech.model.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AlunoRepository extends JpaRepository <Aluno, Integer> {
    @Query("SELECT a FROM Aluno a WHERE a.nome LIKE :nome%")
    Iterable<Aluno> findByNome(String nome);
}
