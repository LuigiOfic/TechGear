package com.GearTech.geartech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeartechApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeartechApplication.class, args);
	}

}
