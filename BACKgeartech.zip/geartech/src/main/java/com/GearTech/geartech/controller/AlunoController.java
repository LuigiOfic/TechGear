package com.GearTech.geartech.controller;


import com.GearTech.geartech.model.Aluno;
import com.GearTech.geartech.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/aluno")
public class AlunoController {

    @Autowired
    private AlunoRepository alunoRepository;

    @GetMapping
    public Iterable<Aluno> findAll(){
        return alunoRepository.findAll();
    }

    @GetMapping("/nome/{nome}")
    public Iterable<Aluno> findByNome(@PathVariable String nome){
        return alunoRepository.findByNome(nome);
    }
}
