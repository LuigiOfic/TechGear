import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import styles from './styles';

function TransmissaoScreen () {
  
  const [rotacaoInicial, setRotacaoInicial] = useState('');
  const [rotacaoFinal, setRotacaoFinal] = useState('');
  const [numeroDentesEngrenagem, setNumeroDentesEngrenagem] = useState('');
  const [numeroDentesCoroa, setNumeroDentesCoroa] = useState('');
  const [relacaoTransmissaoTotal, setRelacaoTransmissaoTotal] = useState('');

 
  const calcularRelacaoTransmissao = () => {
   
    const nInicial = parseFloat(rotacaoInicial);
    const nFinal = parseFloat(rotacaoFinal);
    const ZEngrenagem = parseInt(numeroDentesEngrenagem);
    const ZCoroa = parseInt(numeroDentesCoroa);

   
    const relacaoTotal = (nFinal / nInicial) * (ZEngrenagem / ZCoroa);
    
    
    setRelacaoTransmissaoTotal(relacaoTotal.toFixed(2)); // Arredondar para duas casas decimais
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Rotacao Inicial (rpm):</Text>
      <TextInput
        style={styles.input}
        value={rotacaoInicial}
        onChangeText={text => setRotacaoInicial(text)}
        keyboardType="numeric"
      />
      <Text style={styles.label}>Rotacao Final (rpm):</Text>
      <TextInput
        style={styles.input}
        value={rotacaoFinal}
        onChangeText={text => setRotacaoFinal(text)}
        keyboardType="numeric"
      />
      <Text style={styles.label}>Numero de Dentes da Engrenagem:</Text>
      <TextInput
        style={styles.input}
        value={numeroDentesEngrenagem}
        onChangeText={text => setNumeroDentesEngrenagem(text)}
        keyboardType="numeric"
      />
      <Text style={styles.label}>Numero de Dentes da Coroa:</Text>
      <TextInput
        style={styles.input}
        value={numeroDentesCoroa}
        onChangeText={text => setNumeroDentesCoroa(text)}
        keyboardType="numeric"
      />
      <Button title="Calcular Relacao de Transmissao" onPress={calcularRelacaoTransmissao} />
      {relacaoTransmissaoTotal !== '' && (
        <Text style={styles.result}>Relacao de Transmissao Total: {relacaoTransmissaoTotal}</Text>
      )}
    </View>
  );
};

export default TransmissaoScreen;
