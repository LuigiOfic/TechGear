import { StyleSheet, Platform } from "react-native";
/*
...Platform.select({
  web: {

  },
  android: {
    
  },
}),*/

const styles = StyleSheet.create({
  container: {
    height: "100%",
    width: "100%",
    paddingTop: 35,
  },
  header: {
    ...Platform.select({
      web: {
        height: "35%",
      },
      android: {
        height: "30%",
      },
    }),
  },
  linear: {
    height: "100%",
    width: "100%",
  },
  backlogos: {
    ...Platform.select({
      web: {
        alignItems: "center",
        justifyContent: "center",
        resizeMode: "cover", // ou 'stretch' dependendo do comportamento desejado
        flexDirection: "column",
        width: "100%",
      },
      android: {
        alignItems: "center",
        justifyContent: "center",
        resizeMode: "cover", // ou 'stretch' dependendo do comportamento desejado
        flexDirection: "column",
        width: "95%",
      },
    }),
  },
  background: {
    ...Platform.select({
      web: {
        width: "100%",
      },
      android: {
        width: "100%",
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center'
      },
    }),
  },
  backtitle: {
    alignItems: "center",
  },
  title: {
    fontSize: 30,
    fontWeight: "bold",
  },
  logo: {},
  menu: {
    marginTop: "1%",
    marginLeft: "90%",
  },
  Msg: {
    ...Platform.select({
      web: {
        fontSize: 20,
      },
      android: {
        fontSize: 30,
        marginLeft: 15,
      },
    }),
  },
  MsgB: {
    ...Platform.select({
      web: {
        fontSize: 20,
      },
      android: {
        fontSize: 50,
        height: '10%',
        marginTop: 40,
        marginLeft: 15,
      },
    }),
  },
  main: {
    height: "30%",
    justifyContent: "center",
    width: "100%",
    alignItems: "center",
  },
  mainMiddle: {
    flexDirection: "row",
    width: "100%",
    height: "60%",
    justifyContent: "center",
    alignItems: "center",

    width: "60%",
  },
  mainButtons: {
    height: "100%",
    justifyContent: "center",
    marginVertical: 30,

    width: "50%",
  },
  mainImage: {
    marginLeft: "60%",

  },
  Btn: {
    height: 40,
    width: 150,
    borderRadius: 5,
    padding: 10,
    backgroundColor: "#212529",
    alignItems: "center",
    marginLeft: 50,
    marginTop: 15
  },
  txtBtn: {
    color: "white",
  },
  twoGear: {},
});
export default styles;
