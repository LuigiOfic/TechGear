import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import styles from './styles';


const Engrenagens = () => {
  const [modulo, setModulo] = useState('');
  const [diametro, setDiametro] = useState('');
  const [anguloConeCabeca, setAnguloConeCabeca] = useState('');
  const [alturaDente, setAlturaDente] = useState('');
  const [alturaCabecaDente, setAlturaCabecaDente] = useState('');
  const [folgaCabeca, setFolgaCabeca] = useState('');

  const calcularMedidas = () => {
    const moduloNumber = parseFloat(modulo);

    if (isNaN(moduloNumber)) {

      return;
    }

    const alturaDenteCalculada = moduloNumber * 2.25;
    const alturaCabecaDenteCalculada = moduloNumber * 2.5;
    const folgaCabecaCalculada = moduloNumber * 0.25;

    setAlturaDente(alturaDenteCalculada.toFixed(2));
    setAlturaCabecaDente(alturaCabecaDenteCalculada.toFixed(2));
    setFolgaCabeca(folgaCabecaCalculada.toFixed(2));
  };

  return (

<View style={styles.container}>


<Text style={styles.title}>Cálculos de Engrenagens</Text>

<View style={styles.inputContainer}>
  <Text style={styles.label}>Módulo:</Text>
  <TextInput
    value={modulo}
    onChangeText={setModulo}
    style={styles.input}
    keyboardType="numeric"
    placeholder="Digite o módulo"
  />
</View>

<View style={styles.inputContainer}>
  <Text style={styles.label}>Diâmetro:</Text>
  <TextInput
    value={diametro}
    onChangeText={setDiametro}
    style={styles.input}
    keyboardType="numeric"
    placeholder="Digite o diâmetro"
  />
</View>

<View style={styles.inputContainer}>
  <Text style={styles.label}>Ângulo do Cone da Cabeça:</Text>
  <TextInput
    value={anguloConeCabeca}
    onChangeText={setAnguloConeCabeca}
    style={styles.input}
    keyboardType="numeric"
    placeholder="Digite o ângulo do cone da cabeça"
  />
</View>

<Button title="Calcular Medidas" onPress={calcularMedidas} />

<View style={styles.resultContainer}>
  <Text style={styles.resultText}>Altura do Dente: {alturaDente}</Text>
  <Text style={styles.resultText}>Altura da Cabeça do Dente: {alturaCabecaDente}</Text>
  <Text style={styles.resultText}>Folga da Cabeça: {folgaCabeca}</Text>
</View>
</View>
    
  );
};
  


export default Engrenagens;
